
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>فاتورة <?php echo e($doc->order->reference); ?></title>
<style>
    @page { size: <?php echo e($width); ?>mm auto; margin: 0; }

    * { box-sizing: border-box; }

    html, body {
        margin: 0;
        padding: 0;
        background: #fff;
        color: #000;
    }

    body {
        width: <?php echo e($width); ?>mm;
        padding: 3mm;
        /* A monospace stack keeps the two-column rows aligned; the Arabic
           faces are named first so they win for Arabic glyphs. */
        font-family: "Tahoma", "Arial", "Segoe UI", monospace;
        font-size: <?php echo e($width >= 80 ? '12px' : '11px'); ?>;
        line-height: 1.45;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    .center { text-align: center; }
    .bold   { font-weight: 700; }

    .shop   { font-size: <?php echo e($width >= 80 ? '19px' : '16px'); ?>; font-weight: 700; }
    .kind   { font-size: <?php echo e($width >= 80 ? '17px' : '15px'); ?>; font-weight: 700; }
    .dest   { font-size: <?php echo e($width >= 80 ? '15px' : '13px'); ?>; font-weight: 700; }

    hr {
        border: 0;
        border-top: 1px dashed #000;
        margin: 2mm 0;
    }

    .row {
        display: flex;
        justify-content: space-between;
        gap: 2mm;
    }

    /* The amount must never wrap or shrink — it is the number being checked. */
    .row .amount { white-space: nowrap; font-variant-numeric: tabular-nums; }

    .item      { margin-top: 1.5mm; font-weight: 700; }
    .item-note { padding-inline-start: 4mm; font-weight: 400; font-size: 0.9em; }

    .total {
        font-size: <?php echo e($width >= 80 ? '17px' : '15px'); ?>;
        font-weight: 700;
        border-top: 2px solid #000;
        padding-top: 1.5mm;
        margin-top: 1.5mm;
    }

    .unpaid {
        margin-top: 2mm;
        padding: 1.5mm;
        text-align: center;
        font-weight: 700;
        border: 2px solid #000;
    }

    .footer { margin-top: 3mm; }

    /* Controls are for the screen only; they must never reach the paper. */
    .controls { margin: 4mm 0; text-align: center; }
    .controls button {
        font: inherit;
        padding: 2mm 4mm;
        cursor: pointer;
    }
    @media print { .controls { display: none !important; } }
</style>
</head>
<body>

<div class="center shop"><?php echo e($doc->shopName()); ?></div>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $doc->shopLines(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="center"><?php echo e($line); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>

<div class="center kind"><?php echo e($doc->kind()); ?></div>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($destination = $doc->destination()): ?>
    <div class="center dest"><?php echo e($destination); ?></div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $doc->header(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row"><span><?php echo e($label); ?></span><span class="bold"><?php echo e($value); ?></span></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $doc->items(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row item">
        <span><?php echo e($item['qty']); ?> × <?php echo e($item['name']); ?></span>
        <span class="amount"><?php echo e(number_format($item['total'], 2)); ?></span>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $item['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item-note"><?php echo e($note); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $doc->totals(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row"><span><?php echo e($label); ?></span><span class="amount"><?php echo e(number_format($amount, 2)); ?></span></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="row total">
    <span>الإجمالي</span>
    <span class="amount"><?php echo e(number_format($doc->total(), 2)); ?> ₪</span>
</div>

<div class="row" style="margin-top:1.5mm">
    <span>الدفع</span><span class="bold"><?php echo e($doc->paymentLabel()); ?></span>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($doc->paid())): ?>
    
    <div class="unpaid">*** غير مدفوع ***</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lines = $doc->addressLines()): ?>
    <hr>
    <div class="bold">عنوان التوصيل</div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($line); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($doc->order->notes)): ?>
    <hr>
    <div><span class="bold">ملاحظات:</span> <?php echo e($doc->order->notes); ?></div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>
<div class="center footer"><?php echo e($doc->footer()); ?></div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doc->order->print_count > 0): ?>
    
    <div class="center">— نسخة مُعادة —</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="controls">
    <button onclick="window.print()">طباعة</button>
    <button onclick="window.close()">إغلاق</button>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($autoPrint): ?>
<script>
    // Wait for layout before printing, or the dialog can open against a
    // half-drawn page and produce a blank slip.
    window.addEventListener('load', function () {
        window.setTimeout(function () {
            window.print();
        }, 250);
    });

    // Opened by the cashier screen in a background window: close it once the
    // dialog is done so dockets do not pile up as open tabs.
    window.addEventListener('afterprint', function () {
        if (window.opener) { window.close(); }
    });
</script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</body>
</html>
<?php /**PATH C:\laragon\www\glace\resources\views/receipts/order.blade.php ENDPATH**/ ?>