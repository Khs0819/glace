
<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php
        $settings = $this->settings();
        $shift    = $this->shift();
        $summary  = $this->shiftSummary();
    ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shift): ?>
        <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <div class="text-xs text-gray-500">الوردية مفتوحة منذ</div>
                <div class="text-xl font-bold"><?php echo e($summary['opened'] ?? '—'); ?></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <div class="text-xs text-gray-500">طلبات الوردية</div>
                <div class="text-xl font-bold"><?php echo e($summary['orders'] ?? 0); ?></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <div class="text-xs text-gray-500">النقد المتوقع في الدرج</div>
                <div class="text-xl font-bold"><?php echo e(number_format($summary['expected'] ?? 0, 2)); ?> ₪</div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <div class="text-xs text-gray-500">الطابعة</div>
                <div class="text-xl font-bold">
                    <?php echo e($this->networkPrinter() ? 'شبكية + متصفح' : 'المتصفح فقط'); ?>

                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
        </div>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="text-center py-4">
                <div class="text-lg font-bold">لا توجد وردية مفتوحة</div>
                
                <div class="text-sm text-gray-500 mt-1">
                    افتح وردية قبل استلام أي مبلغ نقدي، وإلا لن يظهر في تقرير الإغلاق.
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div
        x-data="cashierBoard({
            poll:      <?php echo e($settings['poll']); ?>,
            autoPrint: <?php echo e($settings['autoPrint'] ? 'true' : 'false'); ?>,
            width:     <?php echo e($settings['width']); ?>,
            queueUrl:  <?php echo \Illuminate\Support\Js::from(route('receipts.queue'))->toHtml() ?>,
            printUrl:  <?php echo \Illuminate\Support\Js::from(url('admin/receipts'))->toHtml() ?>,
        })"
        x-init="start()"
        wire:ignore
        class="mt-4"
    >
        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-2">
                <span class="relative flex h-3 w-3">
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-3 w-3 bg-primary-500"></span>
                </span>
                <span class="text-sm text-gray-500">
                    تحديث تلقائي كل <span x-text="poll"></span> ثانية ·
                    <span x-text="orders.length"></span> طلب
                </span>
            </div>

            <label class="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" x-model="autoPrint" class="rounded">
                <span>طباعة تلقائية</span>
            </label>
        </div>

        <template x-if="orders.length === 0">
            <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="text-center py-8 text-gray-500">لا توجد طلبات قيد التنفيذ</div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
        </template>

        <div class="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <template x-for="order in orders" :key="order.reference">
                <div
                    class="rounded-xl border-2 bg-white dark:bg-gray-900 p-4 shadow-sm"
                    :class="{
                        'border-amber-400': order.deliveryMethod === 'dine-in',
                        'border-sky-400':   order.deliveryMethod === 'delivery',
                        'border-gray-300':  order.deliveryMethod === 'pickup',
                    }"
                >
                    
                    <div class="flex items-start justify-between gap-2">
                        <div>
                            <div class="text-lg font-black" x-text="order.reference"></div>
                            <div class="text-xs text-gray-500" x-text="timeAgo(order.createdAt)"></div>
                        </div>
                        <div class="text-end">
                            <span
                                class="inline-block rounded-lg px-2 py-1 text-xs font-bold text-white"
                                :class="{
                                    'bg-amber-500': order.deliveryMethod === 'dine-in',
                                    'bg-sky-500':   order.deliveryMethod === 'delivery',
                                    'bg-gray-500':  order.deliveryMethod === 'pickup',
                                }"
                                x-text="kindLabel(order)"
                            ></span>
                        </div>
                    </div>

                    <div class="mt-3 space-y-1 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-500">الزبون</span>
                            <span class="font-semibold" x-text="order.customerName || '—'"></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-500">الهاتف</span>
                            <span x-text="order.customerPhone || '—'"></span>
                        </div>
                        <template x-if="order.deliveryMethod === 'delivery' && order.area">
                            <div class="flex justify-between">
                                <span class="text-gray-500">المنطقة</span>
                                <span class="font-semibold" x-text="order.area"></span>
                            </div>
                        </template>
                        <div class="flex justify-between">
                            <span class="text-gray-500">الأصناف</span>
                            <span x-text="order.itemCount"></span>
                        </div>
                        <div class="flex justify-between text-base">
                            <span class="text-gray-500">الإجمالي</span>
                            <span class="font-black" x-text="Number(order.total).toFixed(2) + ' ₪'"></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-500">الدفع</span>
                            <span>
                                <span x-text="paymentLabel(order.paymentMethod)"></span>
                                <span
                                    class="ms-1 rounded px-1.5 py-0.5 text-xs font-bold"
                                    :class="order.paid ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'"
                                    x-text="order.paid ? 'مدفوع' : 'غير مدفوع'"
                                ></span>
                            </span>
                        </div>
                    </div>

                    
                    <template x-if="order.deliveryMethod === 'dine-in'">
                        <div class="mt-3 flex items-center gap-2">
                            <span class="text-sm text-gray-500">طاولة</span>
                            <template x-if="order.tableNumber">
                                <span class="text-lg font-black" x-text="order.tableNumber"></span>
                            </template>
                            <template x-if="!order.tableNumber">
                                <input
                                    type="text"
                                    placeholder="رقم الطاولة"
                                    class="w-24 rounded-lg border-gray-300 text-sm"
                                    @keydown.enter="$wire.setTable(order.reference, $event.target.value); refresh()"
                                >
                            </template>
                        </div>
                    </template>

                    <div class="mt-3 flex items-center justify-between">
                        <span class="rounded-lg bg-gray-100 dark:bg-gray-800 px-2 py-1 text-xs font-semibold"
                              x-text="order.status"></span>

                        
                        <template x-if="order.printError">
                            <span class="text-xs text-rose-600" title="خطأ الطباعة" x-text="'⚠ ' + order.printError"></span>
                        </template>
                    </div>

                    <div class="mt-3 flex flex-wrap gap-2">
                        <button
                            class="rounded-lg bg-primary-600 px-3 py-2 text-sm font-bold text-white hover:bg-primary-500"
                            @click="print(order, false)"
                        >
                            <span x-text="order.printed ? 'إعادة طباعة' : 'طباعة'"></span>
                        </button>

                        <template x-if="!order.paid && ['cash','visa'].includes(order.paymentMethod)">
                            <button
                                class="rounded-lg bg-emerald-600 px-3 py-2 text-sm font-bold text-white hover:bg-emerald-500"
                                @click="$wire.markPaid(order.reference).then(() => refresh())"
                            >استلام الدفع</button>
                        </template>

                        <button
                            class="rounded-lg border border-gray-300 px-3 py-2 text-sm font-bold hover:bg-gray-50 dark:hover:bg-gray-800"
                            @click="advance(order)"
                        >تحديث الحالة</button>
                    </div>
                </div>
            </template>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function cashierBoard(config) {
            return {
                orders: [],
                poll: config.poll,
                autoPrint: config.autoPrint,
                width: config.width,
                // Every reference this tab has already sent to the printer.
                // Without it a re-poll would reprint the same docket forever.
                printed: new Set(),
                timer: null,

                start() {
                    this.refresh();
                    this.timer = setInterval(() => this.refresh(), this.poll * 1000);

                    // A background tab throttles timers, so the queue is
                    // refreshed the moment it comes back to the front.
                    document.addEventListener('visibilitychange', () => {
                        if (!document.hidden) this.refresh();
                    });
                },

                async refresh() {
                    try {
                        const res = await fetch(config.queueUrl, {
                            headers: { 'Accept': 'application/json' },
                            credentials: 'same-origin',
                        });

                        if (!res.ok) return;

                        const data = await res.json();
                        this.orders = data.orders;

                        if (this.autoPrint) this.printNew();
                    } catch (e) {
                        // A dropped poll is not worth interrupting the counter
                        // over; the next tick picks it up.
                    }
                },

                printNew() {
                    this.orders
                        // Only what the network printer did not already handle.
                        .filter(o => !o.printed && !this.printed.has(o.reference))
                        .forEach(o => this.print(o, true));
                },

                print(order, auto) {
                    this.printed.add(order.reference);

                    const url = config.printUrl + '/' + encodeURIComponent(order.reference)
                        + '?width=' + this.width + (auto ? '&auto=1' : '');

                    // A named window per order: printing three dockets at once
                    // must not have them overwrite each other.
                    window.open(url, 'receipt-' + order.reference, 'width=420,height=700');
                },

                async advance(order) {
                    const options = await this.$wire.nextStatuses(order.reference);

                    if (!options.length) return;

                    const choice = window.prompt(
                        'الحالة الجديدة:\n' + options.map((s, i) => (i + 1) + ') ' + s).join('\n'),
                        '1',
                    );

                    const index = parseInt(choice, 10) - 1;

                    if (isNaN(index) || !options[index]) return;

                    await this.$wire.advance(order.reference, options[index]);
                    this.refresh();
                },

                kindLabel(order) {
                    return {
                        'dine-in':  'داخل المحل' + (order.tableNumber ? ' · طاولة ' + order.tableNumber : ''),
                        'pickup':   'استلام',
                        'delivery': 'توصيل',
                    }[order.deliveryMethod] || order.deliveryMethod;
                },

                paymentLabel(method) {
                    return {
                        'cash': 'نقداً', 'visa': 'بطاقة', 'wallet': 'محفظة',
                        'jawwal': 'جوال باي', 'jawwal-manual': 'جوال باي (تحويل)',
                        'bop': 'بنك فلسطين', 'paypal': 'PayPal',
                    }[method] || method;
                },

                timeAgo(iso) {
                    if (!iso) return '';

                    const minutes = Math.floor((Date.now() - new Date(iso)) / 60000);

                    if (minutes < 1)  return 'الآن';
                    if (minutes < 60) return 'منذ ' + minutes + ' دقيقة';

                    return 'منذ ' + Math.floor(minutes / 60) + ' ساعة';
                },
            };
        }
    </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\glace\resources\views/filament/pages/cashier-board.blade.php ENDPATH**/ ?>